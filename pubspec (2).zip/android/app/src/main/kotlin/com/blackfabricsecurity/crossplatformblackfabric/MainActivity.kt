package com.blackfabricsecurity.crossplatformblackfabric

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
